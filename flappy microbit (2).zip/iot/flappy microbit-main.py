# Imports go at the top
from microbit import *
import random


# Initialize bird and pipe variables
bird_y = 2
pipe_x = 4
pipe_gap = 3
score = 0

# Define game functions
def move_bird():
    global bird_y
    if button_a.was_pressed():
        bird_y -= 1
    elif button_b.was_pressed():
        bird_y += 1

def move_pipes():
    global pipe_x, pipe_gap, score
    pipe_x -= 1
    if pipe_x == 0:
        pipe_x = 4
        pipe_gap = random.randint(1, 3)
        score += 1

def check_collision():
    if bird_y == 0 or bird_y == 4:
        display.show(Image.SKULL)
        sleep(2000)
        reset_game()
    elif pipe_x == 1:
        if bird_y not in range(pipe_gap, pipe_gap + 2):
            display.show(Image.SKULL)
            sleep(2000)
            reset_game()

def update_display():
    display.clear()
    display.set_pixel(1, bird_y, 9)
    display.set_pixel(pipe_x, pipe_gap, 9)
    display.set_pixel(pipe_x, pipe_gap + 1, 9)
    display.scroll("Score: " + str(score))

def reset_game():
    global bird_y, pipe_x, pipe_gap, score
    bird_y = 2
    pipe_x = 4
    pipe_gap = 3
    score = 0

# Main game loop
while True:
    move_bird()
    move_pipes()
    check_collision()
    update_display()
    sleep(100)